var path = require('path');
config.resolve.modules.unshift(path.resolve("./js/min"));