package react

open class ReactExternalComponentSpec<P : RProps>(val ref: dynamic)
