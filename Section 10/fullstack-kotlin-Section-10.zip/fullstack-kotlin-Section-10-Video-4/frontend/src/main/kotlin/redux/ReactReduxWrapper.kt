
@file:JsModule("react-redux")

package redux

import react.RProps
import react.RState
import react.ReactElement


@JsName("connect")
external fun <P : RProps, S : RState, ST : ReduxState> connect(
    mapStateToProps: ((ST, P) -> dynamic)? ,
    mapDispatchToProps: (((ReduxAction) -> Unit, P) -> dynamic)?
): (Any) -> ReactElement
