package com.packtpub

import redux.ReduxState


data class ReduxStore(
    val hash: String = ""
) : ReduxState
